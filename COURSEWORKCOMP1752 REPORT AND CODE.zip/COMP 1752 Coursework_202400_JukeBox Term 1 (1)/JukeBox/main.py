import tkinter as tk
import tkinter.scrolledtext as tkst
import tkinter.font as tkfont
import track_library as lib  # Assume a valid library for managing tracks

# Helper function to update text areas
def set_text(text_area, content):
    """
    Clears the given text_area and sets it to the provided content.
    """
    text_area.delete("1.0", tk.END)
    text_area.insert("1.0", content)

class JukeBoxApp:
    def __init__(self, window):
        self.window = window
        self.window.title("JUKEBOX")
        self.window.geometry("1300x900")
        self.window.configure(bg="gray")

        self.configure_fonts()

        # Header
        tk.Label(
            self.window, text="JUKEBOX APP", font=("Times New Roman", 18), bg="gray"
        ).grid(row=0, column=0, columnspan=4, pady=10)

        # Add components for listing and searching tracks
        tk.Button(self.window, text="LIST ALL TRACKS", command=self.list_all_tracks).grid(
            row=1, column=0, padx=20, pady=20
        )
        tk.Label(self.window, text="TRACK NUMBER:", bg="gray").grid(
            row=1, column=1, padx=20, pady=20
        )
        self.track_input = tk.Entry(self.window, width=20)
        self.track_input.grid(row=1, column=2, padx=20, pady=20)
        tk.Button(self.window, text="VIEW TRACK", command=self.view_track).grid(
            row=1, column=3, padx=20, pady=20
        )

        tk.Label(self.window, text="SEARCH BY NAMES:", bg="gray").grid(
            row=2, column=0, padx=20, pady=20
        )
        self.search_input = tk.Entry(self.window, width=20)
        self.search_input.grid(row=2, column=1, padx=20, pady=20)
        tk.Button(self.window, text="SEARCH", command=self.search_tracks).grid(
            row=2, column=2, padx=20, pady=20
        )

        # Playlist and rating management
        tk.Button(self.window, text="ADD TO PLAYLIST", command=self.add_to_playlist).grid(
            row=3, column=0, padx=20, pady=20
        )
        tk.Label(self.window, text="RATING (1-5):", bg="gray").grid(
            row=3, column=1, padx=20, pady=20
        )
        self.rating_input = tk.Entry(self.window, width=10)
        self.rating_input.grid(row=3, column=2, padx=10, pady=10)
        tk.Button(self.window, text="UPDATE RATING", command=self.update_rating).grid(
            row=3, column=3, padx=20, pady=20
        )

        tk.Button(self.window, text="PLAY PLAYLIST", command=self.play_playlist).grid(
            row=4, column=0, padx=20, pady=20
        )
        tk.Button(self.window, text="RESET PLAYLIST", command=self.reset_playlist).grid(
            row=4, column=1, padx=20, pady=20
        )

        # Text areas for displaying information
        self.track_list_area = tkst.ScrolledText(self.window, width=50, height=20)
        self.track_list_area.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        self.track_details_area = tk.Text(self.window, width=30, height=8)
        self.track_details_area.grid(row=5, column=2, padx=10, pady=10)

        self.playlist_area = tkst.ScrolledText(self.window, width=40, height=20)
        self.playlist_area.grid(row=5, column=3, padx=10, pady=10)

        self.status_lbl = tk.Label(self.window, text="", bg="gray", font=("Times New Roman", 10))
        self.status_lbl.grid(row=6, column=0, columnspan=4, pady=10)

        self.playlist = []

        self.list_all_tracks()  # Load tracks on startup

    def configure_fonts(self):
        family = "Times New Roman"
        tkfont.nametofont("TkDefaultFont").configure(size=15, family=family)

    def list_all_tracks(self):
        track_list = lib.list_all()
        set_text(self.track_list_area, track_list)
        self.status_lbl.config(text="LISTED ALL TRACKS.")

    def view_track(self):
        key = self.track_input.get().strip()
        if not key.isdigit():
            self.status_lbl.config(text="Invalid track number! Use digits only.")
            return
        name = lib.get_name(key)
        if name:
            artist = lib.get_artist(key)
            rating = lib.get_rating(key)
            play_count = lib.get_play_count(key)
            details = f"{name}\n{artist}\nRating: {rating}\nPlays: {play_count}"
            set_text(self.track_details_area, details)
            self.status_lbl.config(text=f"Viewed details for track {key}.")
        else:
            self.status_lbl.config(text=f"Track {key} not found.")

    def search_tracks(self):
        query = self.search_input.get().strip().lower()
        if not query:
            self.status_lbl.config(text="Search query is empty!")
            return
        results = [
            f"Track {key}: {track.name} by {track.artist}"
            for key, track in lib.library.items()
            if query in track.name.lower() or query in track.artist.lower()
        ]
        if results:
            set_text(self.track_list_area, "\n".join(results))
            self.status_lbl.config(text=f"Found {len(results)} result(s) for '{query}'.")
        else:
            set_text(self.track_list_area, "No tracks found.")
            self.status_lbl.config(text=f"No results found for '{query}'.")

    def add_to_playlist(self):
        key = self.track_input.get().strip()
        if not key.isdigit():
            self.status_lbl.config(text="Invalid track number! Use digits only.")
            return
        name = lib.get_name(key)
        if name and name not in self.playlist:
            self.playlist.append(name)
            self.update_playlist_display()
            self.status_lbl.config(text=f"Added '{name}' to the playlist.")
        elif name:
            self.status_lbl.config(text=f"'{name}' is already in the playlist.")
        else:
            self.status_lbl.config(text=f"Track {key} not found.")

    def update_rating(self):
        key = self.track_input.get().strip()
        new_rating = self.rating_input.get().strip()
        if not (new_rating.isdigit() and 1 <= int(new_rating) <= 5):
            self.status_lbl.config(text="Invalid rating! Enter a value between 1 and 5.")
            return
        name = lib.get_name(key)
        if name:
            lib.update_rating(key, int(new_rating))
            self.status_lbl.config(text=f"UPDATED RATING FOR '{name}' TO {new_rating}.")
        else:
            self.status_lbl.config(text=f"TRACK {key} NOT FOUND.")

    def update_playlist_display(self):
        set_text(self.playlist_area, "\n".join(self.playlist))

    def play_playlist(self):
        if not self.playlist:
            self.status_lbl.config(text="PLAYLIST IS EMPTY!")
            return
        for track_name in self.playlist:
            track_num = self.get_track_number_by_name(track_name)
            if track_num:
                lib.increment_play_count(track_num)
        self.status_lbl.config(text="PLAYLIST PLAYED! PLAY COUNT UPDATED.")

    def reset_playlist(self):
        self.playlist = []
        self.update_playlist_display()
        self.status_lbl.config(text="PLAYLIST RESET.")

    def get_track_number_by_name(self, name):
        for key, item in lib.library.items():
            if item.name == name:
                return key
        return None

if __name__ == "__main__":
    window = tk.Tk()
    JukeBoxApp(window)
    window.mainloop()





        

