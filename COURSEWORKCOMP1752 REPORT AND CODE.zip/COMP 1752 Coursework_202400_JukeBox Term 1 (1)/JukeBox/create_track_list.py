import tkinter as tk
import tkinter.scrolledtext as tkst
import track_library as lib

class CreateTrackList:
    def __init__(self, window):
        window.title("Create Track List")
        window.geometry("800x400")

        # Input section
        tk.Label(window, text="Enter Track Number").grid(row=0, column=0, padx=20, pady=20)
        self.track_input = tk.Entry(window, width=5)
        self.track_input.grid(row=0, column=1, padx=10, pady=10)

        tk.Button(window, text="Add to Playlist", command=self.add_to_playlist).grid(row=0, column=2, padx=10, pady=10)
        tk.Button(window, text="Play Playlist", command=self.play_playlist).grid(row=1, column=0, columnspan=2, pady=10)
        tk.Button(window, text="Reset Playlist", command=self.reset_playlist).grid(row=1, column=2, pady=10)

        # Playlist display
        self.playlist_area = tkst.ScrolledText(window, width=60, height=15, wrap="none")
        self.playlist_area.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

        # Status display
        self.status_lbl = tk.Label(window, text="", font=("Helvetica", 10))
        self.status_lbl.grid(row=3, column=0, columnspan=3, sticky="W", padx=10, pady=10)

        # Playlist storage
        self.playlist = []

    def add_to_playlist(self):
        track_num = self.track_input.get().strip()
        track_name = lib.get_name(track_num)

        if track_name:
            if track_name not in self.playlist:
                self.playlist.append(track_name)
                self.update_playlist_display()
                self.status_lbl.config(text=f"Track '{track_name}' added to playlist!")
            else:
                self.status_lbl.config(text=f"Track '{track_name}' is already in the playlist.")
        else:
            self.status_lbl.config(text=f"Track {track_num} not found.")

    def play_playlist(self):
        if not self.playlist:
            self.status_lbl.config(text="Playlist is empty! Add tracks first.")
            return

        for track_name in self.playlist:
            track_num = self.get_track_number_by_name(track_name)
            if track_num:
                lib.increment_play_count(track_num)
        self.status_lbl.config(text="Playlist played! Play counts updated.")

    def reset_playlist(self):
        self.playlist = []
        self.update_playlist_display()
        self.status_lbl.config(text="Playlist reset!")

    def update_playlist_display(self):
        self.playlist_area.delete("1.0", tk.END)
        self.playlist_area.insert(tk.END, "\n".join(self.playlist))

    def get_track_number_by_name(self, name):
        for track_num, details in lib.tracks.items():
            if details["name"] == name:
                return track_num
        return None

if __name__ == "__main__":
    window = tk.Tk()
    CreateTrackList(window)
    window.mainloop()
