import tkinter as tk
import track_library as lib

class UpdateTracks:
    def __init__(self, window):
        window.title("Update Tracks")
        window.geometry("500x300")

        # Input Section
        tk.Label(window, text="Enter Track Number").grid(row=0, column=0, padx=10, pady=10)
        self.track_input = tk.Entry(window, width=5)
        self.track_input.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(window, text="Enter New Rating (1-5)").grid(row=1, column=0, padx=10, pady=10)
        self.rating_input = tk.Entry(window, width=5)
        self.rating_input.grid(row=1, column=1, padx=10, pady=10)

        tk.Button(window, text="Update Rating", command=self.update_rating).grid(row=2, column=0, columnspan=2, pady=10)

        # Status Display
        self.status_lbl = tk.Label(window, text="", font=("Helvetica", 10))
        self.status_lbl.grid(row=3, column=0, columnspan=2, sticky="W", padx=10, pady=10)

    def update_rating(self):
        track_num = self.track_input.get().strip()
        new_rating = self.rating_input.get().strip()

        if not new_rating.isdigit() or not (1 <= int(new_rating) <= 5):
            self.status_lbl.config(text="Invalid rating! Enter a value between 1 and 5.")
            return

        track_name = lib.get_name(track_num)
        if track_name:
            lib.update_rating(track_num, int(new_rating))
            play_count = lib.get_play_count(track_num)
            self.status_lbl.config(
                text=f"Track '{track_name}' updated: New Rating = {new_rating}, Play Count = {play_count}"
            )
        else:
            self.status_lbl.config(text=f"Track {track_num} not found.")

if __name__ == "__main__":
    window = tk.Tk()
    UpdateTracks(window)
    window.mainloop()

