import pytest
from track_library import LibraryItem

def test_libraryitem_creation():
    item = LibraryItem("Test Track", "Test Artist", 3, 0)
    assert item.name == "Test Track"
    assert item.artist == "Test Artist"
    assert item.rating == 3
    assert item.play_count == 0

def test_libraryitem_invalid_rating():
    with pytest.raises(ValueError):
        LibraryItem("Test Track", "Test Artist", 6, 0)  # Rating above 5
